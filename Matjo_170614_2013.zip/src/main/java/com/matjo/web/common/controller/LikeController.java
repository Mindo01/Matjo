package com.matjo.web.common.controller;

import org.springframework.stereotype.Controller;

@Controller
public class LikeController {
	
}
