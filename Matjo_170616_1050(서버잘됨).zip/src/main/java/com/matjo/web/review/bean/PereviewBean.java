package com.matjo.web.review.bean;

public class PereviewBean {
	private String pereviewNo;
	private String pereviewMemId;
	private String pereviewMemName;
	private String pereviewMemImg;
	private String pereviewReviewNo;
	private String pereviewContent;
	private String pereviewRating;
	private String pereviewImgUrl;
	private String pereviewDate;
	
	public String getPereviewNo() {
		return pereviewNo;
	}
	public void setPereviewNo(String pereviewNo) {
		this.pereviewNo = pereviewNo;
	}
	public String getPereviewMemId() {
		return pereviewMemId;
	}
	public void setPereviewMemId(String pereviewMemId) {
		this.pereviewMemId = pereviewMemId;
	}
	public String getPereviewMemName() {
		return pereviewMemName;
	}
	public void setPereviewMemName(String pereviewMemName) {
		this.pereviewMemName = pereviewMemName;
	}
	public String getPereviewMemImg() {
		return pereviewMemImg;
	}
	public void setPereviewMemImg(String pereviewMemImg) {
		this.pereviewMemImg = pereviewMemImg;
	}
	public String getPereviewReviewNo() {
		return pereviewReviewNo;
	}
	public void setPereviewReviewNo(String pereviewReviewNo) {
		this.pereviewReviewNo = pereviewReviewNo;
	}
	public String getPereviewContent() {
		return pereviewContent;
	}
	public void setPereviewContent(String pereviewContent) {
		this.pereviewContent = pereviewContent;
	}
	public String getPereviewRating() {
		return pereviewRating;
	}
	public void setPereviewRating(String pereviewRating) {
		this.pereviewRating = pereviewRating;
	}
	public String getPereviewImgUrl() {
		return pereviewImgUrl;
	}
	public void setPereviewImgUrl(String pereviewImgUrl) {
		this.pereviewImgUrl = pereviewImgUrl;
	}
	public String getPereviewDate() {
		return pereviewDate;
	}
	public void setPereviewDate(String pereviewDate) {
		this.pereviewDate = pereviewDate;
	}
	
	
} // end of class
