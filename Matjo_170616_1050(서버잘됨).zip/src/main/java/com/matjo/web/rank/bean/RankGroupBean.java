package com.matjo.web.rank.bean;

public class RankGroupBean {
	
	private String groupNo;
	private String groupName;
	private String countGroupRank;
	private String groupInfo;
	private String groupImg;
	
	public String getGroupNo() {
		return groupNo;
	}
	public void setGroupNo(String groupNo) {
		this.groupNo = groupNo;
	}
	public String getGroupName() {
		return groupName;
	}
	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}
	public String getCountGroupRank() {
		return countGroupRank;
	}
	public void setCountGroupRank(String countGroupRank) {
		this.countGroupRank = countGroupRank;
	}
	public String getGroupInfo() {
		return groupInfo;
	}
	public void setGroupInfo(String groupInfo) {
		this.groupInfo = groupInfo;
	}
	public String getGroupImg() {
		return groupImg;
	}
	public void setGroupImg(String groupImg) {
		this.groupImg = groupImg;
	}
	
}
