package com.matjo.web.common.dao;

public interface LikeDao {

}
