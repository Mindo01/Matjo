package com.matjo.web.common.bean;

public class CommonBean {
	
	private String memberNo;
	private String noticeNo;
	private String noticeDate;
	private String inquiryNo;
	private String inquiryDate;
	
	public String getMemberNo() {
		return memberNo;
	}
	public String getNoticeNo() {
		return noticeNo;
	}
	public String getNoticeDate() {
		return noticeDate;
	}
	public void setMemberNo(String memberNo) {
		this.memberNo = memberNo;
	}
	public void setNoticeNo(String noticeNo) {
		this.noticeNo = noticeNo;
	}
	public void setNoticeDate(String noticeDate) {
		this.noticeDate = noticeDate;
	}
	public String getInquiryNo() {
		return inquiryNo;
	}
	public String getInquiryDate() {
		return inquiryDate;
	}
	public void setInquiryNo(String inquiryNo) {
		this.inquiryNo = inquiryNo;
	}
	public void setInquiryDate(String inquiryDate) {
		this.inquiryDate = inquiryDate;
	}
	
	
}
